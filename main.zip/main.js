(function(){
"use strict";

/* ========== DATA ========== */
var TRAITS=[
{id:'fisher',n:'钓鱼老手',i:'🎣',d:'稀有渔获概率+20%'},
{id:'camel',n:'骆驼体质',i:'🐫',d:'饥饿消耗-30%'},
{id:'tough',n:'皮糙肉厚',i:'🛡️',d:'生命上限+20，饥饿扣血减半'},
{id:'energy',n:'精力旺盛',i:'⚡',d:'体力上限+20，行动消耗-10%'},
{id:'lucky',n:'幸运儿',i:'🍀',d:'宝箱/漂浮物概率翻倍'}
];

// 鱼种数据，增加 dist 范围，宝箱类增加 s 字段标识等级
var FISH_BASE={
1:[{n:'沙丁鱼',i:'🐟',t:'food',h:15,r:1,w:35,minD:0,maxD:400},
   {n:'鲈鱼',i:'🐠',t:'food',h:22,r:1,w:20,minD:0,maxD:300},
   {n:'海草',i:'🌿',t:'food',h:8,r:1,w:12,minD:0,maxD:700},
   {n:'木板',i:'🪵',t:'mat',s:'wood',r:1,w:14,minD:0,maxD:700},
   {n:'塑料瓶',i:'🧴',t:'mat',s:'plastic',r:1,w:8,minD:0,maxD:700},
   {n:'破渔网',i:'🕸️',t:'junk',r:1,w:5,minD:0,maxD:700},
   {n:'漂浮木箱',i:'📦',t:'chest',s:'chest_1',r:2,w:3,minD:0,maxD:700}],
2:[{n:'金枪鱼',i:'🐟',t:'food',h:28,r:2,w:24,minD:100,maxD:600},
   {n:'石斑鱼',i:'🐠',t:'food',h:35,r:2,w:16,minD:100,maxD:500},
   {n:'海龟蛋',i:'🥚',t:'food',h:18,r:2,w:8,minD:50,maxD:400},
   {n:'金属片',i:'🔩',t:'mat',s:'metal',r:2,w:14,minD:100,maxD:700},
   {n:'绳索',i:'🪢',t:'mat',s:'rope',r:2,w:10,minD:100,maxD:700},
   {n:'贝壳',i:'🐚',t:'cur',s:'shell',r:2,w:8,minD:100,maxD:700},
   {n:'密封宝箱',i:'🧰',t:'chest',s:'chest_2',r:3,w:3,minD:150,maxD:700}],
3:[{n:'深海鳕鱼',i:'🐡',t:'food',h:40,r:3,w:20,minD:350,maxD:700},
   {n:'剑鱼',i:'🗡️',t:'food',h:45,r:3,w:12,minD:300,maxD:700},
   {n:'珍珠贝',i:'🦪',t:'cur',s:'pearl',r:3,w:6,minD:350,maxD:700},
   {n:'精钢片',i:'⚙️',t:'mat',s:'metal',r:3,w:12,minD:350,maxD:700},
   {n:'古代金币',i:'🪙',t:'cur',s:'shell',r:3,w:8,minD:400,maxD:700},
   {n:'传说宝箱',i:'💰',t:'chest',s:'chest_3',r:4,w:3,minD:450,maxD:700},
   {n:'珊瑚',i:'🪸',t:'cur',s:'shell',r:3,w:10,minD:300,maxD:700}],
4:[{n:'龙鱼',i:'🐉',t:'food',h:55,r:4,w:18,minD:600,maxD:9999},
   {n:'远古芯片',i:'💾',t:'mat',s:'chip',r:4,w:5,minD:650,maxD:9999},
   {n:'寒铁',i:'🧊',t:'mat',s:'coldiron',r:4,w:8,minD:700,maxD:9999},
   {n:'黑曜石',i:'🖤',t:'mat',s:'obsidian',r:4,w:7,minD:650,maxD:9999},
   {n:'神秘图纸',i:'📜',t:'bp',r:4,w:3,minD:600,maxD:9999},
   {n:'传说宝箱',i:'💰',t:'chest',s:'chest_4',r:4,w:5,minD:650,maxD:9999}]
};
var FISH={1:[],2:[],3:[],4:[]};
for(var lv in FISH_BASE){FISH[lv]=FISH_BASE[lv].slice();}

// 宝箱掉落池（与等级无关，可通用）
var CHEST_LOOT=[{n:'木板',i:'🪵',t:'mat',s:'wood',c:[2,5]},{n:'塑料瓶',i:'🧴',t:'mat',s:'plastic',c:[2,4]},{n:'金属片',i:'🔩',t:'mat',s:'metal',c:[1,3]},{n:'贝壳',i:'🐚',t:'cur',s:'shell',c:[3,6]},{n:'绳索',i:'🪢',t:'mat',s:'rope',c:[1,3]},{n:'珍珠',i:'💎',t:'cur',s:'pearl',c:[1,2]}];

var RODS=[{lv:1,n:'竹木竿',d:'近海鱼池'},{lv:2,n:'碳素竿',d:'中层·优良',cost:{wood:4,metal:2,plastic:3}},{lv:3,n:'海钓轮竿',d:'深海·精品',cost:{wood:3,metal:6,rope:4}},{lv:4,n:'声呐探鱼竿',d:'显示品质',cost:{wood:2,metal:4,chip:1,obsidian:2}}];

var BLDS=[
{id:'fire',n:'火堆',i:'🔥',lvs:[{d:'熟食回复×1.2·不降健康',c:{wood:3,plastic:2}},{d:'解锁炖锅·×1.5',c:{wood:4,metal:3}},{d:'解锁熏制',c:{wood:3,metal:4,rope:2}},{d:'移动厨房',c:{metal:5,chip:1,obsidian:1},bp:1}]},
{id:'shelter',n:'庇护所',i:'🏠',lvs:[{d:'休息+8体·船耐久+15',c:{wood:5,plastic:3,rope:2}},{d:'休息+12体·风暴减伤30%·耐久+15',c:{wood:6,metal:4,rope:3}},{d:'休息+18体·减伤60%·耐久+20',c:{wood:4,metal:6,rope:4}},{d:'气象站·耐久+20',c:{metal:5,chip:1,obsidian:2},bp:1}]},
{id:'storage',n:'储物箱',i:'📦',lvs:[{d:'背包20格',c:{wood:4,metal:2}},{d:'背包35格',c:{wood:5,metal:4}},{d:'背包50格',c:{wood:3,metal:5,rope:3}},{d:'背包80格',c:{metal:6,chip:1,coldiron:2},bp:1}]}
];

var BAG_LV=[16,20,35,50,80];

var SHOP=[{id:'bait',n:'鱼饵',i:'🪱',d:'下3次钓鱼品质+1',p:{pearl:5},stk:5},{id:'repair',n:'修理锤',i:'🔧',d:'回复20生命',p:{pearl:10},stk:3},{id:'map',n:'海图',i:'🗺️',d:'预览下个岛屿',p:{pearl:15},stk:2},{id:'revive',n:'复活剂',i:'💊',d:'死亡自动复活',p:{pearl:25},stk:1},{id:'radio',n:'旧收音机',i:'📻',d:'恢复精神+20（一次性）',p:{pearl:30},stk:1}];

var TRADE_T=[
{g:{n:'沙丁鱼',i:'🐟',m:'沙丁鱼'},gn:3,r:{n:'木板',i:'🪵',t:'mat',s:'wood'},rn:3},
{g:{n:'鲈鱼',i:'🐠',m:'鲈鱼'},gn:2,r:{n:'贝壳',i:'🐚',t:'cur',s:'shell'},rn:4},
{g:{n:'木板',i:'🪵',m:'_wood'},gn:4,r:{n:'金属片',i:'🔩',t:'mat',s:'metal'},rn:2},
{g:{n:'海草',i:'🌿',m:'海草'},gn:5,r:{n:'绳索',i:'🪢',t:'mat',s:'rope'},rn:2},
{g:{n:'塑料瓶',i:'🧴',m:'_plastic'},gn:3,r:{n:'贝壳',i:'🐚',t:'cur',s:'shell'},rn:3},
{g:{n:'贝壳',i:'🐚',m:'_shell'},gn:6,r:{n:'金属片',i:'🔩',t:'mat',s:'metal'},rn:3},
{g:{n:'金枪鱼',i:'🐟',m:'金枪鱼'},gn:1,r:{n:'珍珠',i:'💎',t:'cur',s:'pearl'},rn:1},
{g:{n:'绳索',i:'🪢',m:'_rope'},gn:2,r:{n:'木板',i:'🪵',t:'mat',s:'wood'},rn:5}
];

var ISLANDS=[
{hr:72,n:'无名小岛',i:'🏝️',d:'不起眼的小岛，有浆果和木料。',loot:[{n:'浆果',i:'🫐',t:'food',h:18,c:3},{n:'木板',i:'🪵',t:'mat',s:'wood',c:5}],req:null,minD:0,maxD:500},
{hr:200,n:'珊瑚礁岛',i:'🪸',d:'珊瑚环绕，浅滩散落贝壳和珍珠。',loot:[{n:'贝壳',i:'🐚',t:'cur',s:'shell',c:8},{n:'珍珠',i:'💎',t:'cur',s:'pearl',c:2}],req:'hull',minD:150,maxD:600},
{hr:360,n:'神秘岛',i:'🌋',d:'薄雾笼罩，隐藏古老秘密...',loot:[{n:'精钢片',i:'⚙️',t:'mat',s:'metal',c:4},{n:'珍珠',i:'💎',t:'cur',s:'pearl',c:3},{n:'神秘图纸',i:'📜',t:'bp',c:1}],req:'canvas',minD:350,maxD:700},
{hr:510,n:'火山群岛',i:'🌋',d:'岩浆入海，硫磺弥漫。',loot:[{n:'黑曜石',i:'🖤',t:'mat',s:'obsidian',c:4},{n:'精钢片',i:'⚙️',t:'mat',s:'metal',c:3}],req:'ram',minD:500,maxD:9999},
{hr:660,n:'冰封暗域',i:'❄️',d:'极寒之地，冰层下封存远古文明。',loot:[{n:'寒铁',i:'🧊',t:'mat',s:'coldiron',c:4},{n:'远古芯片',i:'💾',t:'mat',s:'chip',c:2}],req:'ram',minD:700,maxD:9999}
];

var SHIP_UP=[{id:'hull',n:'加固船底',i:'🔧',d:'前往珊瑚礁岛',c:{wood:6,metal:4}},{id:'canvas',n:'防火帆布',i:'🧵',d:'前往神秘岛',c:{wood:4,metal:3,rope:4}},{id:'ram',n:'破冰撞角',i:'⚔️',d:'前往火山/冰封',c:{metal:6,coldiron:2,obsidian:2}}];

var TALENTS=[{id:'survival',n:'生存系',i:'🏕️',d:'开局带物资·饥饿-5%',fn:function(g){addI(g,'木板','🪵','mat','wood',3);addI(g,'沙丁鱼','🐟','food',null,2);g._hMod*=0.95;}},{id:'fishing',n:'渔猎系',i:'🎣',d:'开局鱼竿Lv.2',fn:function(g){g.rod=2;}},{id:'explore',n:'探索系',i:'🧭',d:'航速+10%·首岛正面事件',fn:function(g){g._spMod*=1.1;g._firstEv=true;}}];

var RECIPES=[
{id:'bait_basic',n:'基础饵',i:'🪱',desc:'钓鱼品质+1（单次）',cost:{'海草':2,'淡水':1},result:{n:'基础饵',t:'mat',s:'bait',q:1}},
{id:'bait_glow',n:'夜光饵',i:'✨',desc:'钓鱼品质+2（深海额外稀有）',cost:{'荧光水母':3,'淡水':1},result:{n:'夜光饵',t:'mat',s:'bait_glow',q:1}},
{id:'herbal_tea',n:'草药茶',i:'🍵',desc:'恢复精神+15',cost:{'海草':2,'淡水':2},result:{n:'草药茶',t:'food',h:0,well:15,q:1}}
];

var ZONES=[
{id:'near',label:'🌊近海',minD:0,maxD:149},
{id:'shelf',label:'🌊远海',minD:150,maxD:399},
{id:'deep',label:'🌊深海',minD:400,maxD:699},
{id:'polar',label:'❄️极地',minD:700,maxD:99999}
];
function getZone(dist){
  for(var i=0;i<ZONES.length;i++){
    if(dist>=ZONES[i].minD && dist<=ZONES[i].maxD) return ZONES[i];
  }
  return ZONES[ZONES.length-1];
}

/* ========== RANDOM EVENTS (Sea) ========== */
var SEA_EV=[
{id:'bottle',n:'漂流瓶',i:'🍾',ch:.15,desc:'海面漂来一个玻璃瓶，里面似乎有东西...',zone:['near','shelf'],
  opts:[{t:'📖 打开阅读',fn:function(g){g._mapFrags=(g._mapFrags||0)+1;return g._mapFrags>=3?'集齐3片藏宝图碎片！发现了隐藏暗礁的位置！（航速永久+10%）'+(g._spMod*=1.1,''):'获得藏宝图碎片'+g._mapFrags+'/3。';}},{t:'🗑️ 扔掉',fn:function(){return '你扔掉了瓶子。';}}]},
{id:'mirage',n:'海市蜃楼',i:'🌅',ch:.08,desc:'远处海面上出现了若隐若现的陆地轮廓...',zone:['near','shelf'],
  opts:[{t:'🏃 追过去',fn:function(g){adv(2);return '追了2小时...只是幻影，白跑了。';}},{t:'🚫 无视',fn:function(){return '你明智地没有偏离航线。';}}]},
{id:'whale_hit',n:'鲸鱼撞击',i:'🐋',ch:.10,desc:'一头巨鲸突然从水下冲出，直撞木筏！',zone:['shelf','deep'],
  opts:[{t:'↩️ 紧急转向',fn:function(g){g.stamina=Math.max(0,g.stamina-5);adv(1);return '紧急转向躲开了！消耗1小时和5体力。';}},{t:'💪 硬扛',fn:function(g){g.durability=Math.max(0,g.durability-10);var lost=dropRandom(g,2);return '木筏耐久-10！'+(lost?'散落物资：'+lost:'还好物资没丢。');}}]},
{id:'flyfish',n:'飞鱼群',i:'🐟',ch:.12,cond:function(g){return g.hour>=5&&g.hour<=8;},desc:'一群飞鱼掠过海面！',zone:['near','shelf'],
  opts:[{t:'🥅 张网拦截',fn:function(g){var c=3+Math.floor(Math.random()*3);addI(g,'飞鱼','🐟','food',null,c);return '捕获'+c+'条飞鱼！';}},{t:'👀 观看',fn:function(){return '飞鱼群远去了。';}}]},
{id:'fog',n:'浓雾弥漫',i:'🌫️',ch:.15,desc:'浓雾从四面八方涌来，能见度几乎为零。',zone:['shelf','deep'],
  opts:[{t:'⚓ 停锚等待',fn:function(g){adv(3);return '等了3小时，雾散了。';}},{t:'➡️ 继续航行',fn:function(g){adv(1);return '硬闯浓雾，偏离航线多耗了1小时。';}}]},
{id:'ice',n:'浮冰区',i:'🧊',ch:.20,cond:function(g){return g.day>=25;},desc:'前方出现大片浮冰！',zone:['polar'],
  opts:[{t:'🔄 缓慢绕行',fn:function(g){adv(2);addI(g,'浮冰','🧊','mat','ice',10);return '绕行2小时，收集了10份浮冰（可融为淡水）。';}},{t:'💥 破冰直行',fn:function(g){g.stamina=Math.max(0,g.stamina-5);g.durability=Math.max(0,g.durability-5);return '破冰前进！体力-5，船耐久-5。';}}]},
{id:'volcano',n:'海上火山喷发',i:'🌋',ch:.10,cond:function(g){return g.visitedIslands&&g.visitedIslands.includes('火山群岛');},desc:'远处火山剧烈喷发，岩浆流入大海！',zone:['deep','polar'],
  opts:[{t:'🏃 全速逃离',fn:function(g){g.stamina=Math.max(0,g.stamina-15);adv(3);return '拼命逃离！体力-15，耗时3小时。';}},{t:'🪨 捡拾浮石',fn:function(g){var c=3+Math.floor(Math.random()*3);addI(g,'火山玻璃','🖤','mat','obsidian',c);g.hp=Math.max(0,g.hp-5);return '获得'+c+'块火山玻璃！但被碎石划伤，生命-5。';}}]},
{id:'rainbow',n:'彩虹出现',i:'🌈',ch:.05,desc:'雨后天空出现一道绚丽的彩虹。',zone:['near','shelf','deep'],
  opts:[{t:'🙏 许愿',fn:function(g){var r=Math.random();if(r<.33){g.hunger=Math.min(g.maxH,g.hunger+20);return '饥饿恢复20点！';}if(r<.66){g.stamina=Math.min(g.maxS,g.stamina+20);return '体力恢复20点！';}g.hp=Math.min(g.maxHp,g.hp+20);return '生命恢复20点！';}},{t:'😊 欣赏',fn:function(){return '美丽的彩虹让你心情愉悦。';}}]},
{id:'shark',n:'鲨鱼围船',i:'🦈',ch:.20,cond:function(g){return countFood(g)>=3;},desc:'几条鲨鱼在木筏周围盘旋，似乎闻到了鱼肉的气味...',zone:['shelf','deep'],
  opts:[{t:'🐟 丢鱼肉引开',fn:function(g){removeFood(g,3);return '丢出3条鱼，鲨鱼追着鱼走了。';}},{t:'🔱 用鱼叉驱赶',fn:function(g){g.stamina=Math.max(0,g.stamina-5);addI(g,'鲨鱼鳍','🦈','mat','sharkfin',1);return '搏斗一番！体力-5，获得鲨鱼鳍×1。';}},{t:'⏳ 静观其变',fn:function(){return '半小时后鲨鱼自行散去。';}}]},
{id:'dolphin',n:'海豚相伴',i:'🐬',ch:.10,desc:'一群友善的海豚在木筏旁嬉戏！',zone:['near','shelf'],
  opts:[{t:'🎮 跟它们玩',fn:function(g){adv(1);g.stamina=Math.min(g.maxS,g.stamina+5);return '和海豚玩耍1小时，体力+5！';}},{t:'👋 不理睬',fn:function(){return '海豚游走了。';}}]},
{id:'raft_empty',n:'无人皮筏',i:'🚣',ch:.07,desc:'发现一只无人的皮筏在海面漂浮。',zone:['near','shelf','deep'],
  opts:[{t:'🔍 打捞查看',fn:function(g){var items=[];for(var i=0;i<2+Math.floor(Math.random()*3);i++){var l=CHEST_LOOT[Math.floor(Math.random()*CHEST_LOOT.length)];var c=rng(l.c[0],l.c[1]);addI(g,l.n,l.i,l.t,l.s,c);items.push(l.i+l.n+'×'+c);}return '搜刮到：'+items.join('、');}},{t:'🪝 拖回木筏',fn:function(g){adv(2);addI(g,'皮革','🟤','mat','leather',3);return '耗时2小时拆解皮筏，获得皮革×3。';}},{t:'⏩ 绕行',fn:function(){return '你绕开了皮筏。';}}]},
{id:'jellyfish',n:'夜光水母潮',i:'🪼',ch:.12,cond:function(g){return g.hour>=20||g.hour<=4;},desc:'海面被荧光水母照亮，如梦如幻。',zone:['deep','polar'],
  opts:[{t:'🥅 捕捞',fn:function(g){adv(1);var c=2+Math.floor(Math.random()*3);addI(g,'荧光水母','🪼','mat','jelly',c);return '耗时1小时，捕获'+c+'只荧光水母（可制夜光鱼饵）。';}},{t:'👀 观赏',fn:function(){return '水母群渐渐远去。';}}]},
{id:'earthquake',n:'海底地震',i:'💥',ch:.05,cond:function(g){return g.visitedIslands&&g.visitedIslands.includes('火山群岛');},desc:'海底传来剧烈震动，木筏猛烈摇晃！',zone:['deep','polar'],
  opts:[{t:'🔧 加强锚固',fn:function(g){adv(2);g.stamina=Math.max(0,g.stamina-10);return '耗时2小时加固，体力-10，物资安全。';}},{t:'🎲 听天由命',fn:function(g){var lost=dropRandom(g,3);return '物资散落！'+(lost?'失去：'+lost:'还好没丢什么。');}}]},
{id:'albatross',n:'信天翁降落',i:'🦅',ch:.06,desc:'一只疲惫的信天翁降落在木筏上。',zone:['near','shelf'],
  opts:[{t:'✊ 捉住它',fn:function(g){g.hp=Math.max(0,g.hp-3);addI(g,'信天翁羽毛','🪶','mat','feather',1);return '被啄了一下（生命-3），获得信天翁羽毛（高级鱼漂材料）。';}},{t:'🐟 喂食',fn:function(g){if(!removeFood(g,1)){return '没有鱼肉可以喂...';}g._albatross=true;return '信天翁吃了鱼，决定跟随你！每天自动赠1条鱼。';}}]},
{id:'oil',n:'油污带',i:'🛢️',ch:.10,cond:function(g){return g.day<=10;},desc:'海面漂浮着一片油污。',zone:['near'],
  opts:[{t:'🫙 收集废油',fn:function(g){var c=2+Math.floor(Math.random()*2);addI(g,'废油团','🛢️','mat','oil',c);return '收集到'+c+'个废油团（可加工为燃料）。';}},{t:'↩️ 绕行',fn:function(g){adv(1);return '绕行多耗1小时。';}}]},
{id:'coconut',n:'漂浮椰子树',i:'🥥',ch:.08,desc:'一棵连根拔起的椰子树在海面漂浮。',zone:['near','shelf'],
  opts:[{t:'🥥 捞起',fn:function(g){var c=3+Math.floor(Math.random()*3);addI(g,'椰子','🥥','food',null,c);addI(g,'淡水','💧','fresh',null,c);return '获得'+c+'个椰子和'+c+'份淡水！';}},{t:'⏩ 无视',fn:function(){return '椰子树漂走了。';}}]},
{id:'radio',n:'无线电信号',i:'📻',ch:.06,desc:'微弱的无线电信号从远处传来...',zone:['shelf','deep','polar'],
  opts:[{t:'📡 尝试应答',fn:function(g){adv(1);var next=null;for(var i=0;i<ISLANDS.length;i++){if(!g.visitedIslands||!g.visitedIslands.includes(ISLANDS[i].n)){next=ISLANDS[i];break;}}if(next){return '获知前方岛屿信息：'+next.i+next.n+'（约'+Math.ceil(next.hr/24)+'天后到达）。';}return '只收到静电噪音...';}},{t:'🔇 保持静默',fn:function(){return '你没有回应。';}}]},
{id:'pre_storm',n:'暴风雨前夕',i:'⛈️',ch:.99,cond:function(g){return g._stormComing;},desc:'天色骤变，暴风雨即将来临！你还有3小时准备。',zone:['near','shelf','deep','polar'],
  opts:[{t:'🔧 加固木筏',fn:function(g){adv(2);if(cntSub(g,'wood')>=5&&cntSub(g,'metal')>=5){consumeSub(g,'wood',5);consumeSub(g,'metal',5);g._stormPrep='half';return '消耗木料5+金属5，风暴损失减半！';}return '材料不足（需木料5+金属5），无法加固！';}},{t:'⛵ 提前收帆',fn:function(g){adv(1);g._stormPrep='slow';return '收帆降速，风暴中航速减半但损失降低。';}},{t:'😰 什么都不做',fn:function(g){g._stormPrep='none';return '听天由命...';}}]}
];

/* ========== FISHING EVENTS ========== */
var FISH_EV=[
{id:'bigfish',n:'大鱼上钩',i:'🎣',ch:.15,desc:'鱼竿剧烈弯曲，这绝对是个大家伙！',zone:['near','shelf','deep','polar'],
  opts:[{t:'⏳ 耐心遛鱼',fn:function(g){adv(1);var pool=getFishPool(g);var rares=pool.filter(function(f){return f.r>=3;});var pick=rares.length?rares[Math.floor(Math.random()*rares.length)]:pool[pool.length-1];if(totalBag(g)<g.bagMax){addI(g,pick.n,pick.i,pick.t,pick.s||null,1);var qn=['','普通','优良','精品','传说'][pick.r]||'';return '经过1小时搏斗，钓到了'+pick.i+pick.n+'（'+qn+'）！';}return '背包满了，大鱼跑了...';}},{t:'💪 强行拉线',fn:function(){return '鱼线断了！本次渔获丢失。';}},{t:'❌ 放弃',fn:function(){return '你放走了它。';}}]},
{id:'boot',n:'钓到靴子',i:'👢',ch:.05,desc:'钓上来一只破旧的靴子...',zone:['near','shelf'],
  opts:[{t:'🔍 检查靴子',fn:function(g){var c=1+Math.floor(Math.random()*3);g.shells+=c*3;return '靴子里藏有'+c+'枚古代钱币（'+c*3+'贝壳）！';}},{t:'🗑️ 扔回海里',fn:function(){return '你把靴子扔了回去。';}}]},
{id:'double',n:'双鱼咬钩',i:'🎣',ch:.08,desc:'两条鱼同时咬钩了！',zone:['near','shelf','deep'],
  opts:[{t:'🤲 左右开弓',fn:function(g){adv(1);for(var i=0;i<2;i++){var pool=getFishPool(g);var pick=wRand(pool);if(pick.t==='food'&&totalBag(g)<g.bagMax){addI(g,pick.n,pick.i,pick.t,pick.s||null,1);}}return '成功！一次获得2条鱼！';}},{t:'🐟 选大的拉',fn:function(g){var pool=getFishPool(g);var rares=pool.filter(function(f){return f.r>=2;});var pick=rares.length?rares[Math.floor(Math.random()*rares.length)]:pool[0];if(totalBag(g)<g.bagMax){addI(g,pick.n,pick.i,pick.t,pick.s||null,1);}return '获得'+pick.i+pick.n+'（优良级以上）。';}}]},
{id:'tangle',n:'鱼线缠住',i:'🧶',ch:.10,desc:'糟糕，鱼线缠成一团了！',zone:['near','shelf'],
  opts:[{t:'🔓 慢慢解',fn:function(g){adv(1);return '花了1小时解开鱼线。';}},{t:'✂️ 割线重绑',fn:function(g){if(cntSub(g,'rope')>=1){consumeSub(g,'rope',1);return '用了1条绳索重新绑好。';}adv(1);return '没有绳索可用！只能慢慢解（耗时1小时）。';}}]},
{id:'monster',n:'咬钩巨物',i:'👹',ch:.12,cond:function(g){return g.hour>=20||g.hour<=4;},desc:'鱼竿几乎被拖走！水下有个巨大的影子...',zone:['deep','polar'],
  opts:[{t:'⚔️ 拼命搏斗',fn:function(g){adv(2);g.stamina=Math.max(0,g.stamina-15);if(Math.random()<.3){addI(g,'龙鱼','🐉','food',null,1);return '经过殊死搏斗，钓上了传说中的龙鱼！（体力-15）';}return '搏斗了2小时，巨物挣脱逃走了...（体力-15）';}},{t:'😨 放弃',fn:function(){return '你明智地放手了。';}}]},
{id:'basket',n:'鱼篓破损',i:'🧺',ch:.10,cond:function(g){return g.totFish>0&&g.totFish%5===0;},desc:'鱼篓出现了裂缝！',zone:['near','shelf','deep','polar'],
  opts:[{t:'🔧 立即修补',fn:function(g){adv(1);if(cntSub(g,'wood')>=2){consumeSub(g,'wood',2);return '消耗2木料修补好了。';}return '木料不足！暂时用布条绑了绑。';}},{t:'🤷 暂时不管',fn:function(g){var lost=Math.min(2,totalBag(g));if(lost>0){dropRandom(g,lost);}return lost+'条鱼从破洞逃走了！';}}]}
];

/* ========== ISLAND EVENTS ========== */
var ISL_EV=[
{n:'废弃营地',i:'⛺',desc:'发现一个被遗弃的营地...',opts:[{t:'🔍 搜索营地',fn:function(g){adv(1);var items=[];for(var i=0;i<2+Math.floor(Math.random()*3);i++){var l=CHEST_LOOT[Math.floor(Math.random()*CHEST_LOOT.length)];var c=rng(l.c[0],l.c[1]);addI(g,l.n,l.i,l.t,l.s,c);items.push(l.i+c);}return '搜到：'+items.join('、');}},{t:'😴 休息片刻',fn:function(g){adv(1);g.stamina=Math.min(g.maxS,g.stamina+10);return '休息1小时，体力+10。';}}]},
{n:'洞穴回声',i:'🕳️',desc:'岛上有个深邃的洞穴，里面传来回声...',opts:[{t:'🔦 深入探索',fn:function(g){adv(2);if(Math.random()<.4){addI(g,'神秘图纸','📜','bp',null,1);return '在洞穴深处找到了蓝图碎片！';}addI(g,'金属片','🔩','mat','metal',4);return '发现了一些稀有矿石。';}},{t:'👀 洞口查看',fn:function(g){adv(1);addI(g,'木板','🪵','mat','wood',3);return '洞口捡了些材料。';}},{t:'❌ 不进去',fn:function(){return '你决定不冒险。';}}]},
{n:'果树茂盛',i:'🌳',desc:'岛上有一片茂盛的果树！',opts:[{t:'🧺 大量采摘',fn:function(g){adv(1);var c=5+Math.floor(Math.random()*4);addI(g,'水果','🍎','food',null,c);return '采摘了'+c+'个水果！';}},{t:'✨ 挑最好的',fn:function(g){adv(1);addI(g,'精品水果','🍑','food',null,3);g.invI['精品水果']='🍑';return '获得3个精品水果（恢复效果翻倍）！';}}]},
{n:'动物脚印',i:'🐾',desc:'地上有新鲜的动物脚印...',opts:[{t:'👣 追踪',fn:function(g){adv(2);if(Math.random()<.5){addI(g,'毛皮','🟫','mat','leather',2);return '追踪到动物巢穴，获得毛皮×2！';}addI(g,'鸟蛋','🥚','food',null,4);return '发现一窝鸟蛋×4！';}},{t:'⏩ 无视',fn:function(){return '你继续前行。';}}]},
{n:'暴雨倾盆',i:'🌧️',desc:'登岛时突降暴雨！',opts:[{t:'🏠 找山洞躲雨',fn:function(g){adv(1);return '在山洞里躲了1小时雨。';}},{t:'🏃 冒雨采集',fn:function(g){adv(2);var items=[];for(var i=0;i<3;i++){var l=CHEST_LOOT[Math.floor(Math.random()*CHEST_LOOT.length)];var c=rng(l.c[0],l.c[1]);addI(g,l.n,l.i,l.t,l.s,c);items.push(l.i+c);}g._cold=true;return '获得物资'+items.join('、')+'，但浑身湿透（感冒：体力消耗+20%，直到休息）。';}}]},
{n:'古老石碑',i:'🗿',desc:'岛上矗立着一块古老的石碑...',opts:[{t:'📝 拓印碑文',fn:function(g){adv(1);addI(g,'知识碎片','📜','bp',null,1);return '拓印了碑文，获得知识碎片！';}},{t:'⛏️ 挖掘碑底',fn:function(g){adv(2);var c=5+Math.floor(Math.random()*4);g.shells+=c;return '挖到'+c+'枚古代钱币（'+c+'贝壳）！';}}]},
{n:'蜂窝',i:'🐝',desc:'树上有个大蜂窝，金黄的蜂蜜正在流淌...',opts:[{t:'🍯 采集蜂蜜',fn:function(g){adv(1);g.hp=Math.max(0,g.hp-10);addI(g,'蜂蜜','🍯','food',null,3);return '被蛰了好几下（生命-10），获得蜂蜜×3（极品食物）！';}},{t:'🚶 避开',fn:function(){return '你绕开了蜂窝。';}}]},
{n:'陷阱坑',i:'⚠️',desc:'前方有个隐蔽的陷阱坑！',opts:[{t:'🔄 小心绕过',fn:function(){return '你小心地绕过了。';}},{t:'👀 查看坑底',fn:function(g){if(Math.random()<.5){addI(g,'海龟','🐢','mat','pet',1);return '坑底有一只被困的海龟，你收养了它！';}return '坑底空空的。';}}]},
{n:'天然温泉',i:'♨️',desc:'发现一处天然温泉！',opts:[{t:'🛁 泡温泉',fn:function(g){adv(2);g.stamina=Math.min(g.maxS,g.stamina+15);g.hp=Math.min(g.maxHp,g.hp+15);return '泡了2小时温泉，体力和生命各+15！';}},{t:'💧 装水带走',fn:function(g){addI(g,'淡水','💧','fresh',null,4);return '装了4份淡水！';}}]},
{n:'海盗宝藏',i:'☠️',desc:'地上有一个海盗宝藏的标记！',opts:[{t:'⛏️ 按标记挖掘',fn:function(g){adv(2);var items=[];for(var i=0;i<4;i++){var l=CHEST_LOOT[Math.floor(Math.random()*CHEST_LOOT.length)];var c=rng(l.c[0],l.c[1])*2;addI(g,l.n,l.i,l.t,l.s,c);items.push(l.i+l.n+'×'+c);}return '挖到宝箱！'+items.join('、');}},{t:'📍 标记位置',fn:function(){return '你记下了位置，下次带工具再来。';}}]},
{n:'求救烟雾',i:'🆘',desc:'远处升起求救的烟雾信号！',opts:[{t:'🏃 前往救援',fn:function(g){adv(2);if((g._crew||0)<3){g._crew=(g._crew||0)+1;return '救下了一位遇难者！他成为你的忠诚船员，将一直跟随你。';}return '你已有3名船员，无法再收留。';}},{t:'😔 忽视',fn:function(){return '你选择不理会...';}}]},
{n:'翡翠矿脉',i:'💎',desc:'岩壁上露出闪闪发光的翡翠矿脉！',opts:[{t:'⛏️ 开采',fn:function(g){adv(3);g.stamina=Math.max(0,g.stamina-20);var c=2+Math.floor(Math.random()*2);addI(g,'翡翠','💚','cur','jade',c);return '耗时3小时，体力-20，获得翡翠×'+c+'（高价值交易品）！';}},{t:'📝 记录位置',fn:function(){return '你记下了矿脉位置。';}}]},
{n:'冰洞',i:'🧊',desc:'冰封暗域中有一个深邃的冰洞...',opts:[{t:'🔦 进洞探索',fn:function(g){adv(2);addI(g,'远古芯片','💾','mat','chip',1);return '在冰洞深处找到远古芯片×1！';}},{t:'🧊 洞口收集',fn:function(g){adv(1);addI(g,'寒冰结晶','💠','mat','icecrystal',3);return '收集到寒冰结晶×3（保鲜材料）。';}}]},
{n:'退潮遗迹',i:'🏛️',desc:'退潮后露出一片古老遗迹...',opts:[{t:'🔍 深入搜寻',fn:function(g){addI(g,'神秘图纸','📜','bp',null,1);return '找到珍贵的古代图纸！';}},{t:'🪨 搬走石板',fn:function(g){addI(g,'木板','🪵','mat','wood',5);addI(g,'金属片','🔩','mat','metal',3);return '搬走大量建材。';}}]}
];

/* ========== NIGHT EVENTS ========== */
var NIGHT_EV=[
{id:'aurora',n:'极光降临',i:'🌌',ch:.10,cond:function(g){return g.day>=25&&(g.hour>=20||g.hour<=4);},desc:'天空中出现绚丽的极光！',zone:['polar'],
  opts:[{t:'✨ 沐浴极光',fn:function(g){adv(1);g._aurora=true;return '极光祝福！次日全属性恢复速度翻倍。';}},{t:'👀 观赏',fn:function(){return '美丽的极光渐渐消散。';}}]},
{id:'meteor',n:'流星雨',i:'☄️',ch:.08,cond:function(g){return g.hour>=21||g.hour<=3;},desc:'漫天流星划过夜空！',zone:['near','shelf','deep','polar'],
  opts:[{t:'🙏 许愿',fn:function(g){var r=Math.random();if(r<.33){g._buff='hunt';return '获得狩猎祝福：24小时内钓鱼品质+1。';}if(r<.66){g._buff='wind';g._spMod*=1.3;return '获得顺风祝福：24小时航速+30%。';}g._buff='shield';return '获得守护祝福：24小时内下次风暴伤害减半。';}},{t:'👀 观赏',fn:function(){return '流星雨渐渐远去。';}}]},
{id:'light',n:'不明灯光',i:'💡',ch:.06,cond:function(g){return g.hour>=20||g.hour<=4;},desc:'远处海面上闪烁着神秘的灯光...',zone:['shelf','deep'],
  opts:[{t:'🚣 靠近查看',fn:function(g){var items=[];for(var i=0;i<3;i++){var l=CHEST_LOOT[Math.floor(Math.random()*CHEST_LOOT.length)];var c=rng(l.c[0],l.c[1])*2;addI(g,l.n,l.i,l.t,l.s,c);items.push(l.i+l.n+'×'+c);}return '发现沉船残骸！搜刮到'+items.join('、');}},{t:'🚫 远离',fn:function(){return '你决定不冒险。';}}]},
{id:'siren',n:'海妖歌声',i:'🧜',ch:.05,cond:function(g){return g.hour>=22||g.hour<=3;},desc:'远处传来空灵的歌声，令人心神恍惚...',zone:['deep','polar'],
  opts:[{t:'🙉 塞住耳朵',fn:function(){return '你捂住了耳朵，歌声渐渐远去。';}},{t:'👂 倾听歌声',fn:function(g){g.hp=Math.max(0,g.hp-10);g._siren=true;return '歌声侵蚀了你的身体（生命-10），但你获得了海妖祝福：钓鱼品质永久+1（本局）。';}}]}
];

/* ========== SPECIAL EVENTS ========== */
var SPECIAL_EV=[
{id:'market',n:'海上集市',i:'🏪',ch:.03,desc:'远处出现一支海上商队！',zone:['near','shelf'],
  opts:[{t:'🤝 停靠交易',fn:function(g){adv(2);g.shells+=10;g.pearls+=2;return '与商队交易了2小时，获得10贝壳+2珍珠！';}},{t:'⏩ 快速通过',fn:function(){return '商队远去了。';}}]},
{id:'archaeo',n:'考古船求救',i:'🚢',ch:.04,desc:'一艘考古船发出求救信号！',zone:['shelf','deep'],
  opts:[{t:'🔧 协助修复',fn:function(g){adv(3);addI(g,'古董花瓶','🏺','cur','antique',1);return '考古学家赠送了古董花瓶×1（高价值交易品）！';}},{t:'💰 索取报酬',fn:function(g){g.pearls+=20;return '获得20颗珍珠！';}},{t:'⏩ 离开',fn:function(){return '你没有停留。';}}]},
{id:'vortex',n:'时间漩涡',i:'🌀',ch:.02,cond:function(g){return g.visitedIslands&&g.visitedIslands.includes('神秘岛');},desc:'海面上出现了一个神秘的漩涡...',zone:['deep','polar'],
  opts:[{t:'🌀 驶入',fn:function(g){g.day=Math.max(1,g.day-3);return '时间倒流了3天！物资保留，时间重置。';}},{t:'🚫 避开',fn:function(){return '你绕开了漩涡。';}}]}
];

/* ========== STATE ========== */
var G=null;

function mkState(trait){
  var maxH=100,maxS=trait==='energy'?120:100,maxHp=trait==='tough'?120:100;
  return {
    trait:trait,day:1,hour:6,hunger:100,stamina:100,hp:100,well:100,durability:100,
    maxH:maxH,maxS:maxS,maxHp:maxHp,maxW:100,maxDur:100,
    rod:1,dist:0,inv:{},invI:{},invT:{},
    bld:{fire:0,shelter:0,storage:0},bagMax:BAG_LV[0],
    shells:0,pearls:0,inhPearls:0,
    trades:[],tLeft:2,shopStk:{},
    bait:0,revive:false,
    vis:[],curIsl:null,shipUp:[],
    _fishB:0,_spB:0,_glowB:0,_noJunk:0,_hMod:1,_spMod:1,_firstEv:false,
    _cold:false,_albatross:false,_crew:0,_mapFrags:0,
    _aurora:false,_buff:null,_siren:false,_stormComing:false,_stormPrep:null,
    totFish:0,totDays:1,selTalent:null,
    briefDone:false,over:false,_lastEv:-1,
    freshWater:0,
    crewJobs:[],
    meditateCooldown:0,
    _lastDayChecked:0
  };
}

/* ========== HELPERS ========== */
function addI(g,n,i,t,s,c){
  if(!g.inv[n]){g.inv[n]=0;}
  g.inv[n]+=c;
  g.invI[n]=i;
  g.invT[n]={t:t,s:s};
}
function remI(g,n,c){
  if(!g.inv[n]||g.inv[n]<c){return false;}
  g.inv[n]-=c;
  if(g.inv[n]<=0){delete g.inv[n];delete g.invI[n];delete g.invT[n];}
  return true;
}
function cntSub(g,s){
  var t=0;
  for(var k in g.inv){
    var i=g.invT[k];
    if(i&&i.s===s){t+=g.inv[k];}
  }
  return t;
}
function hasC(g,c){
  for(var k in c){
    var f=0;
    for(var inv in g.inv){
      var i=g.invT[inv];
      if(i&&(i.s===k||inv===k)){f+=g.inv[inv];}
    }
    if(f<c[k]){return false;}
  }
  return true;
}
function useC(g,c){
  for(var k in c){
    var r=c[k];
    for(var inv in g.inv){
      var i=g.invT[inv];
      if(i&&(i.s===k||inv===k)){
        var t=Math.min(g.inv[inv],r);
        g.inv[inv]-=t;
        r-=t;
        if(g.inv[inv]<=0){delete g.inv[inv];delete g.invI[inv];delete g.invT[inv];}
        if(r<=0){break;}
      }
    }
  }
}

// 修正：背包容量按物品种类数计算
function totalBag(g){
  return Object.keys(g.inv).filter(function(k){ return g.inv[k] > 0; }).length;
}

function countFood(g){
  var t=0;
  for(var k in g.inv){
    var i=g.invT[k];
    if(i&&i.t==='food'){t+=g.inv[k];}
  }
  return t;
}
function removeFood(g,n){
  var rem=n;
  var keys=Object.keys(g.inv);
  for(var idx=0;idx<keys.length;idx++){
    var k=keys[idx];
    var i=g.invT[k];
    if(i&&i.t==='food'){
      var t=Math.min(g.inv[k],rem);
      g.inv[k]-=t;
      rem-=t;
      if(g.inv[k]<=0){delete g.inv[k];delete g.invI[k];delete g.invT[k];}
      if(rem<=0){return true;}
    }
  }
  return rem<=0;
}
function dropRandom(g,n){
  var items=[];
  var keys=Object.keys(g.inv).filter(function(k){return g.inv[k]>0;});
  for(var i=0;i<Math.min(n,keys.length);i++){
    var k=keys[Math.floor(Math.random()*keys.length)];
    var c=Math.min(g.inv[k],1+Math.floor(Math.random()*2));
    g.inv[k]-=c;
    if(g.inv[k]<=0){delete g.inv[k];delete g.invI[k];delete g.invT[k];}
    items.push((g.invI[k]||'')+k+'×'+c);
  }
  return items.join('、');
}
function rng(a,b){return a+Math.floor(Math.random()*(b-a+1));}
function wRand(pool){
  var adj=pool.map(function(it){return {n:it.n,i:it.i,t:it.t,s:it.s,r:it.r,w:it.w,h:it.h,minD:it.minD,maxD:it.maxD};});
  var tw=adj.reduce(function(s,i){return s+i.w;},0);
  var r=Math.random()*tw,c=0;
  for(var idx=0;idx<adj.length;idx++){
    c+=adj[idx].w;
    if(r<=c){return adj[idx];}
  }
  return adj[0];
}

function getFishPool(g){
  var dist=g.dist;
  var all=[];
  for(var lv=1;lv<=4;lv++){
    for(var idx=0;idx<FISH[lv].length;idx++){
      var f=FISH[lv][idx];
      if(dist>=f.minD && dist<=f.maxD){
        all.push(f);
      }
    }
  }
  return all;
}

function eventInZone(e){
  var zone=getZone(G.dist);
  if(!e.zone) return true;
  return e.zone.indexOf(zone.id)>=0;
}

/* ========== SAVE/LOAD ========== */
function save(){
  if(G){
    try{localStorage.setItem('raft3',JSON.stringify(G));}catch(e){}
  }
}
function load(){
  try{
    var s=localStorage.getItem('raft3');
    if(s){G=JSON.parse(s);return true;}
  }catch(e){}
  return false;
}

/* ========== ADVANCE TIME ========== */
function adv(h){
  if(!G||G.over){return;}
  for(var i=0;i<h;i++){
    G.hour++;
    var sp=0.5*(G._spMod||1);
    if(G._spB>0){sp*=2;G._spB--;}
    G.dist+=sp;
    var hd=1.5*(G._hMod||1);
    if(G.trait==='camel'){hd*=0.7;}
    G.hunger=Math.max(0,G.hunger-hd);
    if(G.hunger<=0){var d=3;if(G.trait==='tough'){d=1.5;}G.hp=Math.max(0,G.hp-d);}
    var zone=getZone(G.dist);
    if(zone.id==='deep' || zone.id==='polar'){
      G.well=Math.max(0,G.well-0.2);
    }
    if(G.hunger>60 && G.well>50 && G.hp<G.maxHp) G.hp=Math.min(G.maxHp,G.hp+0.3);
    if(G.well<100 && G.hunger>50) G.well=Math.min(100,G.well+0.3);
    if(G._cold && G.bld.shelter<1){G.stamina=Math.max(0,G.stamina-0.5);}
    if(G._albatross && G.hour===12){addI(G,'沙丁鱼','🐟','food',null,1);}
    if(G.hour===6 && G._crew>0){
      for(var ci=0;ci<G._crew;ci++){
        var job=G.crewJobs[ci]||'none';
        if(job==='repair'){
          G.durability=Math.min(G.maxDur,G.durability+2);
          addLog('🛠️ 船员修船，耐久+2','reward');
        }else if(job==='fish'){
          var pool=getFishPool(G);
          if(pool.length>0){
            var f=pool[Math.floor(Math.random()*pool.length)];
            if(f && totalBag(G)<G.bagMax){
              addI(G,f.n,f.i,f.t,f.s||null,1);
              addLog('🎣 船员钓到'+f.i+f.n,'reward');
            }
          }
        }else if(job==='lookout'){
          G._spMod=(G._spMod||1)*1.05;
        }
      }
    }
    if(G.meditateCooldown>0) G.meditateCooldown--;
    if(G._glowB>0) G._glowB--;
    if(G._noJunk>0) G._noJunk--;
    if(G.hour===6 && G.day>G._lastDayChecked){
      G._lastDayChecked=G.day;
      if(G.vis.length===0 || (G.day - G._lastIslandDay)>3){
        G.well=Math.max(0,G.well-5);
        addLog('🌊 连续多日漂泊，精神-5','danger');
      }
    }
    if(G.hour>24){
      G.hour=1;G.day++;G.totDays=G.day;G.tLeft=2;G.briefDone=false;
      if(G._aurora){G._aurora=false;}
      refreshTrades();
    }
    if(G.hour===6 && !G.briefDone){G.briefDone=true;showBrief();}
    if(G.durability<=0){addLog('💀 木筏散架了！你沉入了大海...','danger');G.hp=0;handleDeath();return;}
    if(G.hour===9 && Math.random()<0.12 && !G._stormComing){G._stormComing=true;}
    if(G.hour===12 && G._stormComing){G._stormComing=false;triggerStorm();}
    if(G.hour%6===0 && G.hour!==G._lastEv && Math.random()<0.25){
      G._lastEv=G.hour;trySeaEvent();
    }
    if(G.well<=0){
      if(Math.random()<0.1){
        var lost=dropRandom(G,1);
        addLog('🧠 精神恍惚，丢失了'+lost,'danger');
      }
    }
    if(G.hp<=0){handleDeath();return;}
  }
  if(G.hp<=0){handleDeath();return;}
  upd();save();
}

function trySeaEvent(){
  var all=SEA_EV.concat(NIGHT_EV).concat(SPECIAL_EV);
  var valid=all.filter(function(e){return (!e.cond||e.cond(G)) && eventInZone(e);});
  for(var i=valid.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var tmp=valid[i];valid[i]=valid[j];valid[j]=tmp;}
  for(var idx=0;idx<valid.length;idx++){
    var e=valid[idx];
    if(Math.random()<e.ch){
      showEvChoice(e.i+' '+e.n,e.desc,e.opts);
      return;
    }
  }
}

function triggerStorm(){
  var lv=G.bld.shelter||0;
  var red=[0,0.3,0.6,0.6,0.9][lv]||0;
  if(G._stormPrep==='half'){red=Math.max(red,0.5);}
  if(G._stormPrep==='slow'){red=Math.max(red,0.3);}
  if(G._stormPrep==='none'){red=0;}
  if(G._buff==='shield'){red=Math.max(red,0.5);G._buff=null;}
  var durDmg=Math.floor((15+Math.random()*20)*(1-red));
  var hpDmg=Math.floor((8+Math.random()*12)*(1-red));
  G.durability=Math.max(0,G.durability-durDmg);
  G.hp=Math.max(0,G.hp-hpDmg);
  var lost='';
  if(red<0.3){lost=dropRandom(G,Math.ceil(Math.random()*3));}
  addLog('⛈️ 暴风雨来袭！船耐久-'+durDmg+'，生命-'+hpDmg+(lost?'，丢失物资：'+lost:'')+(lv>=1?'。庇护所减伤'+Math.round(red*100)+'%':''),red>0.3?'event':'danger');
  G._stormPrep=null;
  if(G.hp<=0||G.durability<=0){handleDeath();}
}

/* ========== ACTIONS ========== */
function doFish(){
  if(G.over){return;}
  var cost=8;if(G.trait==='energy'){cost=Math.ceil(8*0.9);}if(G._cold){cost=Math.ceil(cost*1.2);}
  if(G.stamina<cost){addLog('⚠️ 体力不足！','danger');return;}
  if(totalBag(G) >= G.bagMax){addLog('⚠️ 背包已满！无法再装下更多物品。','danger');return;}
  if(G.well<=0 && Math.random()<0.5){
    addLog('🧠 精神恍惚，鱼跑了...','danger');
    G.stamina-=cost;
    adv(2);
    return;
  }
  G.stamina-=cost;
  var fEv=FISH_EV.filter(function(e){return (!e.cond||e.cond(G)) && eventInZone(e) && Math.random()<e.ch;});
  if(fEv.length>0){
    var e=fEv[Math.floor(Math.random()*fEv.length)];
    showEvChoice(e.i+' '+e.n,e.desc,e.opts);
    adv(2);
    return;
  }
  var pool=getFishPool(G);
  if(pool.length===0){
    addLog('这片海域没有鱼...','danger');
    adv(2);
    return;
  }
  var qb=0;if(G.bait>0){qb=1;G.bait--;}if(G._fishB>0){qb++;G._fishB--;}if(G._glowB>0){qb++;}if(G._siren){qb++;}if(G._buff==='hunt'){qb++;G._buff=null;}
  var rb=(G.trait==='fisher'?0.2:0)+(G.trait==='lucky'?0.15:0);
  var adj=pool.map(function(it){
    var w=it.w;if(it.r>=2){w*=(1+rb+qb*0.25);}
    return {n:it.n,i:it.i,t:it.t,s:it.s,r:it.r,w:w,h:it.h};
  });
  var tw=adj.reduce(function(s,i){return s+i.w;},0);
  var rand=Math.random()*tw,c=0;
  var catch_=adj[0];
  for(var idx=0;idx<adj.length;idx++){
    c+=adj[idx].w;
    if(rand<=c){catch_=adj[idx];break;}
  }
  G.totFish++;

  // 处理不同钓获类型
  if(catch_.t==='chest'){
    // 宝箱作为物品存入背包（占一个槽位）
    if(totalBag(G) < G.bagMax){
      addI(G,catch_.n,catch_.i,catch_.t,catch_.s||'chest_1',1);
      var lvMap={'chest_1':'普通','chest_2':'密封','chest_3':'传说','chest_4':'远古'};
      addLog('🎣 '+catch_.i+catch_.n+'（'+ (lvMap[catch_.s]||'') +'）已放入背包，可点击打开。','reward');
    } else {
      addLog('⚠️ 背包满了，宝箱无法收起...','danger');
    }
  } else if(catch_.t==='cur'){
    if(catch_.s==='shell'){var n2=rng(1,3);G.shells+=n2;addLog('🎣 '+catch_.i+catch_.n+'，+'+n2+'贝壳！','reward');}
    else{G.pearls++;addLog('🎣 '+catch_.i+catch_.n+'，+1珍珠！','reward');}
  } else if(catch_.t==='junk'){
    addLog('🎣 '+catch_.i+catch_.n+'...没用。');
  } else if(catch_.t==='bp'){
    if(totalBag(G) < G.bagMax){
      addI(G,catch_.n,catch_.i,catch_.t,'bp',1);
      addLog('🎣 '+catch_.i+catch_.n+'！珍贵图纸！','reward');
    } else {
      addLog('🎣 '+catch_.i+catch_.n+'，但背包满了！','danger');
    }
  } else {
    if(totalBag(G) < G.bagMax){
      addI(G,catch_.n,catch_.i,catch_.t,catch_.s||null,1);
      var qn=['','普通','优良','精品','传说'][catch_.r]||'';
      addLog('🎣 '+catch_.i+catch_.n+'（'+qn+'）',catch_.r>=2?'reward':'');
    }else{
      addLog('🎣 '+catch_.i+catch_.n+'，但背包满了！','danger');
      adv(2);
      return;
    }
  }
  adv(2);
}

function doRest(){
  if(G.over){return;}
  var base=5;var sl=G.bld.shelter||0;
  if(sl>=1){base=[5,8,12,18,18][sl]||5;}
  if(G._aurora){base*=2;}
  var hrs=Math.min(Math.ceil((G.maxS-G.stamina)/base),8);
  if(hrs<1){hrs=1;}
  G.stamina=Math.min(G.maxS,G.stamina+base*hrs);
  if(G._cold){G._cold=false;addLog('🤧 休息后感冒好了。','reward');}
  addLog('😴 休息'+hrs+'小时，恢复'+base*hrs+'体力。');
  adv(hrs);
}

function doSleep(){
  if(G.over){return;}
  var r=24-G.hour+6;if(r>18){r=24-G.hour+1;}
  G.stamina=G.maxS;
  if(G._cold){G._cold=false;addLog('🤧 睡一觉感冒好了。','reward');}
  addLog('🌙 一觉到天亮...');
  adv(r);
}

function doMeditate(){
  if(G.over){return;}
  if(G.meditateCooldown>0){
    addLog('⏳ 冥想冷却中，还需'+G.meditateCooldown+'小时。','danger');
    return;
  }
  G.well=Math.min(G.maxW,G.well+8);
  G.meditateCooldown=8;
  addLog('🧘 冥想1小时，精神+8。','reward');
  adv(1);
}

function craftRecipe(rid){
  var rec=RECIPES.find(function(r){return r.id===rid;});
  if(!rec) return;
  for(var mat in rec.cost){
    var need=rec.cost[mat];
    var have=0;
    if(mat==='淡水') have=G.freshWater;
    else if(G.inv[mat]) have=G.inv[mat];
    if(have<need){addLog('材料不足：需要'+mat+'×'+need,'danger');return;}
  }
  for(var mat in rec.cost){
    var need=rec.cost[mat];
    if(mat==='淡水') G.freshWater-=need;
    else remI(G,mat,need);
  }
  var res=rec.result;
  if(res.t==='mat' && res.s==='bait'){
    G.bait += res.q;
    addLog('🧪 合成了'+res.q+'个基础饵！','reward');
  }else if(res.t==='mat' && res.s==='bait_glow'){
    G._glowB += res.q*2;
    addLog('✨ 合成了'+res.q+'个夜光饵（品质+2）！','reward');
  }else if(res.n==='草药茶'){
    G.well=Math.min(G.maxW,G.well+res.well);
    addLog('🍵 饮用草药茶，精神+'+res.well+'！','reward');
  }else{
    if(totalBag(G) < G.bagMax){
      addI(G,res.n,rec.i,res.t,res.s||null,res.q);
      addLog('🧪 合成了'+res.n+'！','reward');
    } else {
      addLog('⚠️ 背包已满，合成物无法存放！','danger');
    }
  }
  adv(1);
}

/* ========== INVENTORY ========== */
function renderInv(){
  var g=document.getElementById('invGrid');
  g.innerHTML='';
  var items=Object.entries(G.inv).filter(function(entry){return entry[1]>0;});
  for(var idx=0;idx<items.length;idx++){
    var n=items[idx][0],c=items[idx][1];
    var ic=G.invI[n]||'📦';
    var info=G.invT[n]||{};
    var d=document.createElement('div');
    d.className='inv-slot'+(info.t==='food'?' food':'')+(info.t==='chest'?' chest':'');
    if(info.t==='food'&&G.bld.fire<1){d.className+=' raw-warn';}
    d.innerHTML='<span class="ii">'+ic+'</span><span class="in">'+n+'</span><span class="ic">×'+c+'</span>';
    d.addEventListener('click',function(nn){return function(){showItem(nn);};}(n));
    g.appendChild(d);
  }
  var u=items.length;
  for(var i=u;i<Math.min(G.bagMax,16);i++){
    var d=document.createElement('div');
    d.className='inv-slot empty';
    d.innerHTML='<span class="ii" style="opacity:.15">·</span>';
    g.appendChild(d);
  }
  document.getElementById('bagUsed').textContent=u;
  document.getElementById('bagMax').textContent=G.bagMax;
}

var mItem='';
function showItem(n){
  mItem=n;
  var info=G.invT[n]||{};
  var ic=G.invI[n]||'📦';
  var c=G.inv[n]||0;
  document.getElementById('mTitle').textContent=ic+' '+n+' ×'+c;
  var desc='拥有 '+c+' 个。';
  var actionsHtml='';

  // 宝箱处理
  if(info.t==='chest'){
    var lvMap={'chest_1':1,'chest_2':2,'chest_3':3,'chest_4':4};
    var level=lvMap[info.s]||1;
    desc='🔮 一个神秘的宝箱（等级 '+level+'）。点击打开获得随机战利品！';
    actionsHtml='<button class="mc" id="openChestBtn">打开</button>';
  } else if(info.t==='food'){
    var fi=findFood(n);
    var base=fi?fi.h:12;
    var fl=G.bld.fire||0;
    var mult=fl>=3?1.5:fl>=2?1.5:fl>=1?1.2:1;
    var act=Math.ceil(base*mult);
    var rawWarn=!fl?' ⚠️生食健康-8':'';
    var heal=fl>=1?3:0;
    desc=(fl?'🔥烹饪：':'生吃：')+'恢复'+act+'饥饿'+(heal?'+'+heal+'生命':'')+rawWarn;
    actionsHtml='<button class="mc" id="eatBtn">食用</button>';
  } else if(info.t==='fresh'){
    desc='淡水资源，可饮用或合成。';
    actionsHtml='<button class="mc" id="drinkFreshBtn">饮用（+5精神）</button>';
  } else if(n==='旧收音机'){
    desc='播放音乐，恢复精神+20（一次性）';
    actionsHtml='<button class="mc" id="useRadioBtn">播放</button>';
  } else {
    desc='普通物品。';
  }

  var dropHtml='';
  if(c>0){
    dropHtml='<button class="md" id="dropOneBtn">丢弃1个</button>';
    if(c>1) dropHtml+='<button class="md" id="dropAllBtn">丢弃全部</button>';
  }
  document.getElementById('mDesc').textContent=desc;
  var actionsDiv=document.getElementById('mActions');
  actionsDiv.innerHTML=actionsHtml+dropHtml+'<button class="mx" id="closeItemModal">关闭</button>';

  // 事件绑定
  document.getElementById('closeItemModal').addEventListener('click',closeModal);
  if(document.getElementById('eatBtn')){
    document.getElementById('eatBtn').addEventListener('click',function(){eat(n);});
  }
  if(document.getElementById('drinkFreshBtn')){
    document.getElementById('drinkFreshBtn').addEventListener('click',function(){drinkFresh(n);});
  }
  if(document.getElementById('useRadioBtn')){
    document.getElementById('useRadioBtn').addEventListener('click',function(){useRadio(n);});
  }
  if(document.getElementById('openChestBtn')){
    document.getElementById('openChestBtn').addEventListener('click',function(){openChest(n);});
  }
  if(document.getElementById('dropOneBtn')){
    document.getElementById('dropOneBtn').addEventListener('click',function(){confirmDrop(n,1);});
  }
  if(document.getElementById('dropAllBtn')){
    document.getElementById('dropAllBtn').addEventListener('click',function(){confirmDrop(n,'all');});
  }
  document.getElementById('itemModal').classList.remove('hidden');
}

// 打开宝箱
function openChest(n){
  var info=G.invT[n];
  if(!info || info.t!=='chest') return;
  var lvMap={'chest_1':1,'chest_2':2,'chest_3':3,'chest_4':4};
  var level=lvMap[info.s]||1;
  var count=1+Math.floor(level/2); // 1~3件
  var items=[];
  // 计算需要多少空槽位（每个掉落物占一种）
  var neededSlots=count;
  var currentSlots=totalBag(G);
  if(currentSlots + neededSlots > G.bagMax){
    addLog('⚠️ 背包空间不足，无法打开宝箱（需 '+neededSlots+' 个空槽）！','danger');
    return;
  }
  // 消耗宝箱
  remI(G,n,1);
  // 生成掉落
  for(var i=0;i<count;i++){
    var l=CHEST_LOOT[Math.floor(Math.random()*CHEST_LOOT.length)];
    var c=rng(l.c[0], l.c[1]);
    if(level>=3) c=Math.ceil(c*1.5);
    addI(G,l.n,l.i,l.t,l.s,c);
    items.push(l.i+l.n+'×'+c);
  }
  addLog('🎁 打开宝箱获得：'+items.join('、'),'reward');
  closeModal();
  upd();save();
}

function findFood(n){
  for(var lv=1;lv<=4;lv++){
    for(var idx=0;idx<FISH[lv].length;idx++){
      var f=FISH[lv][idx];
      if(f.n===n&&f.t==='food'){return f;}
    }
  }
  return null;
}
function eat(n){
  if(!G.inv[n]||G.inv[n]<=0){return;}
  var fi=findFood(n);
  var base=fi?fi.h:12;
  var fl=G.bld.fire||0;
  var mult=fl>=3?1.5:fl>=2?1.5:fl>=1?1.2:1;
  var act=Math.ceil(base*mult);
  var heal=fl>=1?3:0;
  remI(G,n,1);
  G.hunger=Math.min(G.maxH,G.hunger+act);
  if(heal){G.hp=Math.min(G.maxHp,G.hp+heal);}
  if(!fl){G.well=Math.max(0,G.well-8);addLog('🍖 生吃'+n+'，+'+act+'饥饿'+(heal?'+'+heal+'生命':'')+'，精神-8⚠️','danger');}
  else{addLog('🍳 烹饪'+n+'，+'+act+'饥饿'+(heal?'+'+heal+'生命':'')+'，精神+3（热食）','reward'); G.well=Math.min(G.maxW,G.well+3);}
  adv(1);
  closeModal();
}
function drinkFresh(n){
  if(!G.inv[n]||G.inv[n]<=0){return;}
  remI(G,n,1);
  G.well=Math.min(G.maxW,G.well+5);
  addLog('💧 饮用淡水，精神+5。','reward');
  adv(1);
  closeModal();
}
function useRadio(n){
  if(!G.inv[n]||G.inv[n]<=0){return;}
  remI(G,n,1);
  G.well=Math.min(G.maxW,G.well+20);
  addLog('📻 播放旧收音机，精神+20！','reward');
  adv(1);
  closeModal();
}
function confirmDrop(n, mode){
  closeModal();
  var title='确认丢弃';
  var desc='确定要丢弃 "'+n+'" ';
  if(mode===1) desc+='1个 吗？';
  else desc+='全部 ('+G.inv[n]+'个) 吗？';
  showConfirm(title,desc,function(confirmed){
    if(confirmed){
      if(mode===1){
        if(remI(G,n,1)){
          addLog('🗑️ 丢弃了 '+n+' ×1。','event');
        }
      }else{
        var cnt=G.inv[n]||0;
        if(cnt>0){
          delete G.inv[n];delete G.invI[n];delete G.invT[n];
          addLog('🗑️ 丢弃了 '+n+' ×'+cnt+'（全部）。','event');
        }
      }
      upd();save();
    }
  });
}
function showConfirm(title,desc,callback){
  document.getElementById('confirmTitle').textContent=title;
  document.getElementById('confirmDesc').textContent=desc;
  var actions=document.getElementById('confirmActions');
  actions.innerHTML='<button class="mc" id="confirmYes">确认</button><button class="mx" id="confirmNo">取消</button>';
  document.getElementById('confirmModal').classList.remove('hidden');
  document.getElementById('confirmYes').addEventListener('click',function(){
    document.getElementById('confirmModal').classList.add('hidden');
    callback(true);
  });
  document.getElementById('confirmNo').addEventListener('click',function(){
    document.getElementById('confirmModal').classList.add('hidden');
    callback(false);
  });
  document.getElementById('confirmBg').addEventListener('click',function(){
    document.getElementById('confirmModal').classList.add('hidden');
    callback(false);
  });
}
function closeModal(){
  document.getElementById('itemModal').classList.add('hidden');
  mItem='';
}

/* ========== CRAFT ========== */
function renderCraft(){
  var cl=document.getElementById('craftList');
  cl.innerHTML='';
  for(var bIdx=0;bIdx<BLDS.length;bIdx++){
    var b=BLDS[bIdx];
    var lv=G.bld[b.id]||0;
    var mx=lv>=4;
    var nx=mx?null:b.lvs[lv];
    var can=false;
    var needBp=false;
    if(nx){
      if(nx.bp){
        // 需要图纸：检查是否有bp物品
        needBp=true;
        var hasBp=false;
        for(var k in G.inv){
          if(G.invT[k] && G.invT[k].t==='bp' && G.inv[k]>0){hasBp=true;break;}
        }
        can = hasBp && hasC(G,nx.c);
      } else {
        can = hasC(G,nx.c);
      }
    }
    var cs='';
    if(nx){
      var cEntries=Object.entries(nx.c);
      var csParts=[];
      for(var ce=0;ce<cEntries.length;ce++){
        var k=cEntries[ce][0],v=cEntries[ce][1];
        var nm={wood:'木',plastic:'塑',metal:'金',rope:'绳',chip:'芯',coldiron:'寒铁',obsidian:'曜'};
        csParts.push((nm[k]||k)+''+cntSub(G,k)+'/'+v);
      }
      cs=csParts.join(' ');
      if(needBp) cs+=' 📜需图纸';
    }
    var d=document.createElement('div');
    d.className='ci';
    d.innerHTML='<span class="ci-icon">'+b.i+'</span><div class="ci-info"><div class="ci-name">'+b.n+' <span style="font-size:9px;color:#a09880">'+(lv?'Lv.'+lv:'未建')+'</span></div><div class="ci-desc">'+(lv>0?b.lvs[lv-1].d:'未建造')+'</div>'+(nx?'<div class="ci-cost">'+cs+'</div>':'')+'</div><button class="cb '+(mx?'built':'')+'" '+(mx||!can?'disabled':'')+' data-build="'+b.id+'">'+(mx?'满级':lv?'升级':'建造')+'</button>';
    cl.appendChild(d);
  }
  var buildBtns=cl.querySelectorAll('[data-build]');
  for(var bb=0;bb<buildBtns.length;bb++){
    (function(btn){
      btn.addEventListener('click',function(){
        var id=btn.getAttribute('data-build');
        build(id);
      });
    })(buildBtns[bb]);
  }

  var ru=document.getElementById('rodUp');
  var nr=RODS.find(function(r){return r.lv===G.rod+1;});
  if(nr){
    var can=hasC(G,nr.cost);
    var csParts2=[];
    var cEntries2=Object.entries(nr.cost);
    for(var ce2=0;ce2<cEntries2.length;ce2++){
      var k=cEntries2[ce2][0],v=cEntries2[ce2][1];
      var nm2={wood:'木',plastic:'塑',metal:'金',rope:'绳',chip:'芯',coldiron:'寒铁',obsidian:'曜'};
      csParts2.push((nm2[k]||k)+''+cntSub(G,k)+'/'+v);
    }
    ru.innerHTML='<div class="ci"><span class="ci-icon">🎣</span><div class="ci-info"><div class="ci-name">Lv.'+nr.lv+' '+nr.n+'</div><div class="ci-desc">'+nr.d+'</div><div class="ci-cost">'+csParts2.join(' ')+'</div></div><button class="cb" '+(can?'':'disabled')+' id="rodUpBtn">升级</button></div>';
    document.getElementById('rodUpBtn').addEventListener('click',upRod);
  }else{
    ru.innerHTML='<div class="ci"><span class="ci-icon">🎣</span><div class="ci-info"><div class="ci-name">最高等级</div></div></div>';
  }
  renderShip();
  renderRecipes();
}

function build(id){
  var b=BLDS.find(function(x){return x.id===id;});
  if(!b){return;}
  var lv=G.bld[id]||0;
  if(lv>=4){return;}
  var nx=b.lvs[lv];
  if(!nx){return;}
  // 检查图纸需求
  if(nx.bp){
    var hasBp=false;
    var bpKey=null;
    for(var k in G.inv){
      if(G.invT[k] && G.invT[k].t==='bp' && G.inv[k]>0){
        hasBp=true; bpKey=k; break;
      }
    }
    if(!hasBp){
      addLog('📜 需要一张图纸才能建造！','danger');
      return;
    }
    // 消耗一张图纸
    remI(G,bpKey,1);
  }
  if(!hasC(G,nx.c)){
    addLog('材料不足！','danger');
    return;
  }
  useC(G,nx.c);
  G.bld[id]=lv+1;
  if(id==='storage'){G.bagMax=BAG_LV[lv+1]||G.bagMax;}
  if(id==='shelter'){
    var durBonus=[0,15,15,20,20][lv+1]||0;
    G.maxDur+=durBonus;
    G.durability=Math.min(G.maxDur,G.durability+durBonus);
    addLog('🛶 船耐久上限+'+durBonus+'！','reward');
  }
  var stCost=10+lv*5;
  G.stamina=Math.max(0,G.stamina-stCost);
  addLog('🔨 '+(lv?'升级':'建造')+b.n+'到Lv.'+(lv+1)+'！'+nx.d,'reward');
  adv(Math.ceil(3+lv*1.5));
}

function upRod(){
  var nr=RODS.find(function(r){return r.lv===G.rod+1;});
  if(!nr||!hasC(G,nr.cost)){return;}
  useC(G,nr.cost);
  G.rod=nr.lv;
  G.stamina=Math.max(0,G.stamina-6);
  addLog('🎣 升级为Lv.'+nr.lv+' '+nr.n+'！','reward');
  adv(2);
}

function renderShip(){
  var d=document.getElementById('shipUp');
  d.innerHTML='';
  for(var idx=0;idx<SHIP_UP.length;idx++){
    var su=SHIP_UP[idx];
    var own=G.shipUp.includes(su.id);
    var can=!own&&hasC(G,su.c);
    var csParts=[];
    var cEntries=Object.entries(su.c);
    for(var ce=0;ce<cEntries.length;ce++){
      var k=cEntries[ce][0],v=cEntries[ce][1];
      var nm={wood:'木',plastic:'塑',metal:'金',rope:'绳',chip:'芯',coldiron:'寒铁',obsidian:'曜'};
      csParts.push((nm[k]||k)+''+cntSub(G,k)+'/'+v);
    }
    var div=document.createElement('div');
    div.className='ci';
    div.innerHTML='<span class="ci-icon">'+su.i+'</span><div class="ci-info"><div class="ci-name">'+su.n+'</div><div class="ci-desc">'+su.d+'</div><div class="ci-cost">'+csParts.join(' ')+'</div></div><button class="cb '+(own?'built':'')+'" '+(own||!can?'disabled':'')+' data-ship="'+su.id+'">'+(own?'已有':'升级')+'</button>';
    d.appendChild(div);
  }
  var shipBtns=d.querySelectorAll('[data-ship]');
  for(var sb=0;sb<shipBtns.length;sb++){
    (function(btn){
      btn.addEventListener('click',function(){
        upShip(btn.getAttribute('data-ship'));
      });
    })(shipBtns[sb]);
  }
}

function upShip(id){
  var su=SHIP_UP.find(function(x){return x.id===id;});
  if(!su||G.shipUp.includes(id)||!hasC(G,su.c)){return;}
  useC(G,su.c);
  G.shipUp.push(id);
  G.stamina=Math.max(0,G.stamina-15);
  addLog('⚓ '+su.n+'完成！'+su.d,'reward');
  adv(4);
}

function renderRecipes(){
  var div=document.getElementById('craftRecipes');
  div.innerHTML='';
  for(var idx=0;idx<RECIPES.length;idx++){
    var rec=RECIPES[idx];
    var costDesc='';
    var can=true;
    for(var mat in rec.cost){
      var need=rec.cost[mat];
      var have=0;
      if(mat==='淡水') have=G.freshWater;
      else have=G.inv[mat]||0;
      costDesc+=mat+' '+have+'/'+need+' ';
      if(have<need) can=false;
    }
    // 检查成品是否会导致背包满（如果是存入背包的）
    var res=rec.result;
    if(res.t!=='food' && res.t!=='cur' && res.t!=='mat' && res.t!=='bp'){
      // 如果产物不是立即使用的，需要检查背包空间
      if(totalBag(G) >= G.bagMax) can=false;
    }
    var btn=document.createElement('button');
    btn.className='action-btn';
    btn.innerHTML=rec.i+' '+rec.n+'<div class="sub">'+rec.desc+' | 消耗：'+costDesc+'</div>';
    btn.disabled=!can;
    btn.addEventListener('click',function(rid){return function(){craftRecipe(rid);};}(rec.id));
    div.appendChild(btn);
  }
}

/* ========== SHOP ========== */
function renderShop(){
  document.getElementById('cShell').textContent=G.shells;
  document.getElementById('cPearl').textContent=G.pearls;
  var l=document.getElementById('shopList');
  l.innerHTML='';
  for(var idx=0;idx<SHOP.length;idx++){
    var it=SHOP[idx];
    var stk=G.shopStk[it.id]!==undefined?G.shopStk[it.id]:it.stk;
    var pk=Object.keys(it.p)[0];
    var pv=it.p[pk];
    var cur=pk==='shell'?'🐚':'💎';
    var can=stk>0&&(pk==='shell'?G.shells:G.pearls)>=pv;
    var d=document.createElement('div');
    d.className='si';
    d.innerHTML='<span class="si-icon">'+it.i+'</span><div class="si-info"><div class="si-name">'+it.n+' <span style="font-size:9px;color:#a09880">×'+stk+'</span></div><div class="si-desc">'+it.d+'</div></div><span class="si-price">'+cur+pv+'</span><button class="td" '+(can?'':'disabled')+' data-shop="'+it.id+'">买</button>';
    l.appendChild(d);
  }
  var shopBtns=l.querySelectorAll('[data-shop]');
  for(var sb=0;sb<shopBtns.length;sb++){
    (function(btn){
      btn.addEventListener('click',function(){
        buy(btn.getAttribute('data-shop'));
      });
    })(shopBtns[sb]);
  }
}

function buy(id){
  var it=SHOP.find(function(x){return x.id===id;});
  if(!it){return;}
  var stk=G.shopStk[id]!==undefined?G.shopStk[id]:it.stk;
  if(stk<=0){return;}
  var pk=Object.keys(it.p)[0];
  var pv=it.p[pk];
  if(pk==='shell'){if(G.shells<pv){return;}G.shells-=pv;}
  else{if(G.pearls<pv){return;}G.pearls-=pv;}
  G.shopStk[id]=stk-1;
  if(id==='bait'){G.bait+=3;addLog('🪱 鱼饵+3次品质加成！','reward');}
  else if(id==='repair'){G.hp=Math.min(G.maxHp,G.hp+20);addLog('🔧 生命+20！','reward');}
  else if(id==='map'){
    var nx=null;
    for(var i=0;i<ISLANDS.length;i++){
      if(!G.vis.includes(ISLANDS[i].n) && G.dist>=ISLANDS[i].minD && G.dist<=ISLANDS[i].maxD){
        nx=ISLANDS[i];break;
      }
    }
    addLog(nx?'🗺️ 下个岛屿：'+nx.i+nx.n+'（约'+Math.ceil(nx.hr/24)+'天后）':'🗺️ 没有更多岛屿了。','reward');
  }else if(id==='revive'){G.revive=true;addLog('💊 死亡自动复活一次！','reward');}
  else if(id==='radio'){
    if(totalBag(G) < G.bagMax){
      addI(G,'旧收音机','📻','cur',null,1);
      addLog('📻 获得旧收音机！','reward');
    } else {
      addLog('⚠️ 背包已满，收音机无法存放！','danger');
    }
  }
  save();upd();
}

/* ========== TRADE ========== */
function refreshTrades(){
  var p=TRADE_T.slice();
  for(var i=p.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var tmp=p[i];p[i]=p[j];p[j]=tmp;}
  G.trades=p.slice(0,3);
  G.tLeft=2;
}
function renderTrade(){
  document.getElementById('tLeft').textContent=G.tLeft;
  var l=document.getElementById('tradeList');
  l.innerHTML='';
  for(var i=0;i<(G.trades||[]).length;i++){
    var t=G.trades[i];
    var can=G.tLeft>0&&hasTradeItem(G,t.g.m,t.gn);
    var d=document.createElement('div');
    d.className='ti';
    d.innerHTML='<span class="ti-icon">'+t.g.i+'→'+t.r.i+'</span><div class="ti-info"><div class="ti-name">'+t.g.n+'×'+t.gn+' → '+t.r.n+'×'+t.rn+'</div></div><button class="td" '+(can?'':'disabled')+' data-trade="'+i+'">换</button>';
    l.appendChild(d);
  }
  var tradeBtns=l.querySelectorAll('[data-trade]');
  for(var tb=0;tb<tradeBtns.length;tb++){
    (function(btn){
      btn.addEventListener('click',function(){
        trade(parseInt(btn.getAttribute('data-trade')));
      });
    })(tradeBtns[tb]);
  }
}
function hasTradeItem(g,m,c){
  if(m[0]==='_'){return cntSub(g,m.slice(1))>=c;}
  return(g.inv[m]||0)>=c;
}
function useTradeItem(g,m,c){
  if(m[0]==='_'){
    var s=m.slice(1);
    var r=c;
    for(var k in g.inv){
      var i=g.invT[k];
      if(i&&i.s===s){
        var t=Math.min(g.inv[k],r);
        g.inv[k]-=t;
        r-=t;
        if(g.inv[k]<=0){delete g.inv[k];delete g.invI[k];delete g.invT[k];}
        if(r<=0){break;}
      }
    }
    return;
  }
  remI(g,m,c);
}
function trade(i){
  if(G.tLeft<=0){return;}
  var t=G.trades[i];
  if(!hasTradeItem(G,t.g.m,t.gn)){return;}
  useTradeItem(G,t.g.m,t.gn);
  if(t.r.t==='cur'){
    if(t.r.s==='shell'){G.shells+=t.rn;}else{G.pearls+=t.rn;}
  }else{addI(G,t.r.n,t.r.i,t.r.t,t.r.s,t.rn);}
  G.tLeft--;
  addLog('🤝 '+t.g.n+'×'+t.gn+' → '+t.r.n+'×'+t.rn,'reward');
  save();upd();
}

/* ========== CREW ========== */
function renderCrew(){
  var count=G._crew||0;
  document.getElementById('crewCount').textContent=count;
  var list=document.getElementById('crewList');
  list.innerHTML='';
  if(count===0){
    list.innerHTML='<div style="color:#8a7e6e;font-size:11px;padding:5px">暂无船员，在岛屿事件中可能救起遇难者。</div>';
    return;
  }
  for(var i=0;i<count;i++){
    var job=G.crewJobs[i]||'none';
    var div=document.createElement('div');
    div.className='ci';
    div.innerHTML='<span class="ci-icon">👤</span><div class="ci-info"><div class="ci-name">船员 '+(i+1)+'</div><div class="ci-desc">当前工作：'+({none:'空闲',repair:'修船',fish:'钓鱼',lookout:'瞭望'}[job]||'空闲')+'</div></div>';
    var btnGroup=document.createElement('div');
    btnGroup.className='crew-btns';
    var jobs=['repair','fish','lookout'];
    var labels=['修船','钓鱼','瞭望'];
    for(var j=0;j<jobs.length;j++){
      var b=document.createElement('button');
      b.className='cb';
      b.textContent=labels[j];
      if(job===jobs[j]) b.classList.add('built');
      b.disabled=(job===jobs[j]);
      (function(ci,jobId){
        b.addEventListener('click',function(){
          G.crewJobs[ci]=jobId;
          addLog('👥 船员'+(ci+1)+'转为'+labels[jobs.indexOf(jobId)]+'工作。','event');
          upd();save();
        });
      })(i,jobs[j]);
      btnGroup.appendChild(b);
    }
    div.appendChild(btnGroup);
    list.appendChild(div);
  }
}

/* ========== ISLAND ========== */
function showIsland(isl){
  document.getElementById('islTitle').textContent=isl.i+' '+isl.n;
  document.getElementById('islDesc').textContent=isl.d;
  document.getElementById('islandOv').classList.remove('hidden');
}
function exploreIsland(){
  var isl=G.curIsl;
  if(!isl){return;}
  G.vis.push(isl.n);
  G._lastIslandDay=G.day;
  var loot=[];
  for(var idx=0;idx<isl.loot.length;idx++){
    var l=isl.loot[idx];
    if(l.t==='cur'){
      if(l.s==='shell'){G.shells+=l.c;loot.push('🐚×'+l.c);}
      else{G.pearls+=l.c;loot.push('💎×'+l.c);}
    }else{
      if(totalBag(G) < G.bagMax){
        addI(G,l.n,l.i,l.t,l.s||null,l.c);
        loot.push(l.i+l.n+'×'+l.c);
      } else {
        loot.push('⚠️'+l.i+l.n+'（背包满未拾取）');
      }
    }
  }
  G.stamina=Math.max(0,G.stamina-12);
  addLog(isl.i+' 探索'+isl.n+'！'+loot.join('、'),'reward');
  if(Math.random()<0.5||G._firstEv){
    G._firstEv=false;
    document.getElementById('islandOv').classList.add('hidden');
    G.curIsl=null;
    var ev=ISL_EV[Math.floor(Math.random()*ISL_EV.length)];
    showEvChoice(ev.i+' '+ev.n,ev.desc,ev.opts);
    return;
  }
  document.getElementById('islandOv').classList.add('hidden');
  G.curIsl=null;
  adv(3);
}
function skipIsland(){
  if(G.curIsl){G.vis.push(G.curIsl.n);}
  document.getElementById('islandOv').classList.add('hidden');
  G.curIsl=null;
  addLog('⛵ 继续航行。');
  save();upd();
}

/* ========== EVENT CHOICE ========== */
function showEvChoice(title,desc,opts){
  document.getElementById('evTitle').textContent=title;
  document.getElementById('evDesc').textContent=desc;
  var c=document.getElementById('evChoices');
  c.innerHTML='';
  for(var idx=0;idx<opts.length;idx++){
    (function(o){
      var b=document.createElement('button');
      b.className='evc';
      b.textContent=o.t;
      b.addEventListener('click',function(){
        var msg=o.fn(G);
        if(msg){addLog(title+'：'+msg,msg.indexOf('！')>=0||msg.indexOf('+')>=0?'reward':'event');}
        document.getElementById('eventOv').classList.add('hidden');
        upd();save();
      });
      c.appendChild(b);
    })(opts[idx]);
  }
  document.getElementById('eventOv').classList.remove('hidden');
}

/* ========== BRIEF ========== */
function showBrief(){
  var w=['☀️ 晴朗','⛅ 多云','🌧️ 小雨','🌊 风浪'][Math.floor(Math.random()*4)];
  var zone=getZone(G.dist);
  var c='第'+G.day+'天 · '+w+' · '+zone.label+'\n🍖'+Math.round(G.hunger)+' ⚡'+Math.round(G.stamina)+' ❤️'+Math.round(G.hp)+' 🧠'+Math.round(G.well)+' 🛶'+Math.round(G.durability)+'\n⛵ '+Math.round(G.dist)+'海里 | 💧淡水 '+G.freshWater;
  if(G._cold){c+='\n🤧 感冒中（体力消耗+20%）';}
  if(G._albatross){c+='\n🦅 信天翁跟随中';}
  if(G._crew>0){c+='\n👥 船员×'+G._crew;}
  if(G.bait>0){c+='\n🪱 鱼饵×'+G.bait;}
  if(G.meditateCooldown>0){c+='\n⏳ 冥想冷却 '+G.meditateCooldown+'h';}
  document.getElementById('briefTitle').textContent='🌅 第'+G.day+'天';
  document.getElementById('briefContent').textContent=c;
  document.getElementById('briefOv').classList.remove('hidden');
}
function closeBrief(){
  document.getElementById('briefOv').classList.add('hidden');
}

/* ========== DEATH ========== */
function handleDeath(){
  G.over=true;
  if(G.revive){
    G.revive=false;G.hp=50;G.hunger=50;G.durability=Math.max(20,G.durability);G.over=false;
    addLog('💊 复活剂生效！','reward');
    upd();save();return;
  }
  var inh=Math.ceil(G.pearls*0.2);
  var pts=Math.floor(G.day/10);
  try{localStorage.setItem('raft3inh',JSON.stringify({pearls:inh,pts:pts}));}catch(e){}
  document.getElementById('deathStats').innerHTML='存活<b>'+G.day+'</b>天<br>航行<b>'+Math.round(G.dist)+'</b>海里<br>钓鱼<b>'+G.totFish+'</b>次<br>岛屿<b>'+G.vis.length+'</b>座<br>记忆碎片<b>'+pts+'</b>点';
  var ts=document.getElementById('talSec');
  ts.innerHTML='';
  if(pts>0){
    ts.innerHTML='<h3>🧬 天赋（'+pts+'点）</h3>';
    for(var idx=0;idx<TALENTS.length;idx++){
      (function(t){
        var b=document.createElement('button');
        b.className='tal-btn';
        b.textContent=t.i+' '+t.n+'：'+t.d;
        b.addEventListener('click',function(){
          G.selTalent=t.id;
          var all=document.querySelectorAll('.tal-btn');
          for(var a=0;a<all.length;a++){all[a].classList.remove('sel');}
          b.classList.add('sel');
        });
        ts.appendChild(b);
      })(TALENTS[idx]);
    }
  }
  document.getElementById('deathOv').classList.remove('hidden');
  save();
}
function restart(){
  document.getElementById('deathOv').classList.add('hidden');
  var inh={pearls:0,pts:0};
  try{var s=localStorage.getItem('raft3inh');if(s){inh=JSON.parse(s);}}catch(e){}
  localStorage.removeItem('raft3');
  showTraits(inh);
}

/* ========== TRAIT SELECT ========== */
function showTraits(inh){
  var l=document.getElementById('traitList');
  l.innerHTML='';
  for(var idx=0;idx<TRAITS.length;idx++){
    (function(t){
      var b=document.createElement('button');
      b.className='tb';
      b.innerHTML='<span class="tbi">'+t.i+'</span><div><div>'+t.n+'</div><div class="tbd">'+t.d+'</div></div>';
      b.addEventListener('click',function(){
        try{
          startGame(t.id,inh);
        }catch(e){
          console.error('启动游戏出错:',e);
          alert('启动失败，请刷新页面重试。');
        }
      });
      l.appendChild(b);
    })(TRAITS[idx]);
  }
  document.getElementById('traitOv').classList.remove('hidden');
}
function startGame(trait,inh){
  G=mkState(trait);
  G.inhPearls=inh.pearls||0;
  G.pearls+=G.inhPearls;
  for(var idx=0;idx<SHOP.length;idx++){G.shopStk[SHOP[idx].id]=SHOP[idx].stk;}
  refreshTrades();
  addI(G,'木板','🪵','mat','wood',2);
  addI(G,'淡水','💧','fresh',null,2);
  if(inh.selTalent){
    var t=TALENTS.find(function(x){return x.id===inh.selTalent;});
    if(t){t.fn(G);}
  }
  document.getElementById('traitOv').classList.add('hidden');
  var ti=TRAITS.find(function(t){return t.id===trait;});
  addLog('特质「'+ti.n+'」——'+ti.d,'reward');
  if(G.inhPearls>0){addLog('继承'+G.inhPearls+'珍珠。','reward');}
  addLog('一叶孤筏，茫茫大海。开始求生吧。');
  G._lastIslandDay=1;
  showBrief();
  upd();save();
}

/* ========== LOG ========== */
function addLog(text,type){
  var a=document.getElementById('log');
  var d=document.createElement('div');
  d.className='log-entry'+(type?' '+type:'');
  d.innerHTML='<div class="tt">第'+(G?G.day:1)+'天 '+(G?G.hour:0)+':00</div>'+text;
  a.appendChild(d);
  a.scrollTop=a.scrollHeight;
  while(a.children.length>120){a.removeChild(a.firstChild);}
}

/* ========== UI ========== */
function upd(){
  if(!G){return;}
  document.getElementById('dDay').textContent=G.day;
  document.getElementById('dHour').textContent=G.hour;
  document.getElementById('dDist').textContent=Math.round(G.dist);
  var zone=getZone(G.dist);
  document.getElementById('zoneLabel').textContent=zone.label;
  var setBar=function(id,val,max){
    document.getElementById(id).style.width=Math.max(0,Math.min(100,val/max*100))+'%';
  };
  setBar('bHunger',G.hunger,G.maxH);
  document.getElementById('vHunger').textContent=Math.round(G.hunger);
  setBar('bStam',G.stamina,G.maxS);
  document.getElementById('vStam').textContent=Math.round(G.stamina);
  setBar('bHp',G.hp,G.maxHp);
  document.getElementById('vHp').textContent=Math.round(G.hp);
  setBar('bWell',G.well,G.maxW);
  document.getElementById('vWell').textContent=Math.round(G.well);
  setBar('bDur',G.durability,G.maxDur);
  document.getElementById('vDur').textContent=Math.round(G.durability);
  document.getElementById('freshWater').textContent=G.freshWater;

  var w=[];
  if(G.hunger<20){w.push('⚠️饥饿');}
  if(G.stamina<15){w.push('⚠️体力');}
  if(G.hp<20){w.push('⚠️生命');}
  if(G.well<20){w.push('⚠️精神');}
  if(G.durability<20){w.push('⚠️船耐久');}
  var wb=document.getElementById('warn');
  if(w.length){wb.textContent=w.join(' ');wb.classList.add('show');}else{wb.classList.remove('show');}

  var bb=document.getElementById('buffBar');
  bb.innerHTML='';
  if(G._cold){bb.innerHTML+='<span class="buff-tag debuff">🤧感冒</span>';}
  if(G._albatross){bb.innerHTML+='<span class="buff-tag">🦅信天翁</span>';}
  if(G._crew){bb.innerHTML+='<span class="buff-tag">👥船员×'+G._crew+'</span>';}
  if(G._siren){bb.innerHTML+='<span class="buff-tag">🧜海妖祝福</span>';}
  if(G._stormComing){bb.innerHTML+='<span class="buff-tag debuff">⛈️风暴将至</span>';}
  if(G.bait>0){bb.innerHTML+='<span class="buff-tag">🪱鱼饵×'+G.bait+'</span>';}
  if(G._glowB>0){bb.innerHTML+='<span class="buff-tag">✨夜光饵×'+G._glowB+'</span>';}
  if(G.meditateCooldown>0){bb.innerHTML+='<span class="buff-tag">⏳冥想冷却</span>';}

  var ri=RODS.find(function(r){return r.lv===G.rod;});
  document.getElementById('rodLv').textContent='Lv.'+G.rod+' '+(ri?ri.n:'');
  document.getElementById('baitInfo').textContent=G.bait>0?'(鱼饵×'+G.bait+')':'';

  renderInv();
  renderCraft();
  renderShop();
  renderTrade();
  renderCrew();
}

function stab(n,btn){
  var allBtns=document.querySelectorAll('.tab-btn');
  for(var i=0;i<allBtns.length;i++){allBtns[i].classList.remove('active');}
  btn.classList.add('active');
  var panels=document.querySelectorAll('.panel');
  for(var i=0;i<panels.length;i++){panels[i].classList.remove('active');}
  document.getElementById('p'+n).classList.add('active');
}

/* ========== INIT ========== */
function init(){
  try{
    // Tab buttons
    var tabBtns=document.querySelectorAll('.tab-btn');
    for(var i=0;i<tabBtns.length;i++){
      (function(btn){
        btn.addEventListener('click',function(){
          var tab=btn.getAttribute('data-tab');
          stab(tab,btn);
        });
      })(tabBtns[i]);
    }

    // Action buttons
    document.getElementById('fishBtn').addEventListener('click',doFish);
    document.getElementById('restBtn').addEventListener('click',doRest);
    document.getElementById('sleepBtn').addEventListener('click',doSleep);
    document.getElementById('meditateBtn').addEventListener('click',doMeditate);

    // Island buttons
    document.getElementById('exploreBtn').addEventListener('click',exploreIsland);
    document.getElementById('skipBtn').addEventListener('click',skipIsland);

    // Brief button
    document.getElementById('briefBtn').addEventListener('click',closeBrief);

    // Restart
    document.getElementById('restartBtn').addEventListener('click',restart);

    // Try load or show traits
    if(load()&&G&&!G.over){
      addLog('（存档已加载）');
      upd();
    }else{
      var inh={pearls:0,pts:0};
      try{var s=localStorage.getItem('raft3inh');if(s){inh=JSON.parse(s);}}catch(e){}
      showTraits(inh);
    }
  }catch(e){
    console.error('初始化错误:',e);
    alert('游戏加载出错，请刷新页面重试。');
  }
}

if(document.readyState==='loading'){
  document.addEventListener('DOMContentLoaded',init);
}else{
  init();
}

})();